package com.artursworld.nccn.view.user;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.artursworld.nccn.R;

public class SelectUserActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_user);
    }
}
