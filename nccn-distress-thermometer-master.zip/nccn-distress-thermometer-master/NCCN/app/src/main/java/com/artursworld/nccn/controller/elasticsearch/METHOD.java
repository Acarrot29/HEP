package com.artursworld.nccn.controller.elasticsearch;

/**
 * Contains supported HTTP METHODS
 */
public enum METHOD {
        POST, PUT
}
