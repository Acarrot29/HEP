package com.artursworld.nccn.model.entity;


public interface IQuestionnaire {
    int getProgressInPercent();
}
